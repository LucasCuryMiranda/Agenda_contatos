package com.example.agenda_contatos.dao
import androidx.room.Dao
import androidx.room.Insert
import com.example.agenda_contatos.model.Usuario


@Dao
interface UsuarioDao {
    @Insert
    fun inserir(listausuarios: MutableList<Usuario>)
}

