package com.example.agenda_contatos

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.agenda_contatos.dao.UsuarioDao
import com.example.agenda_contatos.model.Usuario


@Database(entities = [Usuario::class], version = 1)

abstract class AppDatabase : RoomDatabase() {

    abstract fun usuarioDao(): UsuarioDao
    companion object{
        private const val DATABASE_name: String = "DB_USUARIO"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this){
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DATABASE_name
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
